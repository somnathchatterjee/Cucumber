package com.demo.base;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class DriverManager extends  ConfigurationManager{
	
	public static ConfigurationManager configarationManager = new ConfigurationManager();
    public static WebDriver driver;
    public static String path = System.getProperty("user.dir");


    public static void browser() throws IOException {

        configarationManager.conficfile();
        String Url = config.getProperty("URL");
        String browsername = config.getProperty("browser" );
        if(browsername.equalsIgnoreCase("Firefox")){
            System.setProperty("webdriver.gecko.driver", path+"/Driver/geckodriver.exe");
            driver = new FirefoxDriver();
            driver.manage().window().maximize();
        }else if(browsername.equalsIgnoreCase("Chrome")){
            System.setProperty("webdriver.chrome.driver", path+"/Driver/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
        }
    driver.get(Url);

    }

}
