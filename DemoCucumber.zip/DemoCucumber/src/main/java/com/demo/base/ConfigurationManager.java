package com.demo.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationManager {
	
	public static Properties config;
    public static Properties OR; //object Repository
    public static Properties TestData;

    public static String path = System.getProperty("user.dir");


    public static void conficfile() throws IOException {

        //Read confic file
        File con = new File(path+"/src/main/resources/Resource/config.properties");
        FileInputStream file = new FileInputStream(con);
        config = new Properties();
        config.load(file);
        System.out.println(config.getProperty("browser"));

        //Read OR file
        File con1 = new File(path+"/src/main/resources/Resource/OR.properties");
        FileInputStream file1 = new FileInputStream(con1);
        OR = new Properties();
        OR.load(file1);

        //Read TestData file
        File con2 = new File(path+"/src/main/resources/Resource/TestData.properties");
        FileInputStream file2 = new FileInputStream(con2);
        TestData = new Properties();
        TestData.load(file2);

    }

    public static String getxpath(String key){
        return OR.getProperty(key);
    }

}
