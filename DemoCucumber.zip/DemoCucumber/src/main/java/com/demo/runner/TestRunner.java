package com.demo.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;
import com.demo.base.DriverManager;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;



@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\main\\resources\\Feature"
		,glue= {"com.demo.stepDefination"},
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:report/cucumber-report.html"},
		tags = {"@testData1"},
		monochrome = true
		//,dryRun = true
		
		
		)
public class TestRunner extends DriverManager{
	
	@AfterClass
	public static void reportSetup() {
		Reporter.loadXMLConfig(System.getProperty("user.dir")+"\\src\\main\\resources\\extendreports.xml");
		driver.quit();
	}
	
}
