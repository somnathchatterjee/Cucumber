package com.demo.stepDefination;

import com.demo.pageObject.CheckBox;
import com.demo.pageObject.TextBox;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;

public class ValidateDemoQa {
	CheckBox cb = new CheckBox();
	TextBox tb = new TextBox();

	@Given("^As a user I navigated to DemoQA$")
	public void as_a_user_I_navigated_to_DemoQA() throws Exception {
		cb.init();
	}

	@Given("^As a user I clicked checkbox$")
	public void as_a_user_I_clicked_checkbox() throws Exception {
		cb.clickCheckBox();
		Thread.sleep(2000);
	}

	@Then("^I clicked Textbox button$")
	public void i_clicked_Textbox_button() throws Exception {
		tb.clickTextBox();
		Thread.sleep(2000);
	}

	@Then("^I enter data into textbox full name$")
	public void i_enter_data_into_textbox_full_name() throws Exception {
		tb.enterFullName();
		Thread.sleep(2000);
	}

}
