package com.demo.pageObject;

import com.demo.base.TestBase;

public class TextBox extends TestBase{
	
	public static TestBase base = new TestBase();
	
	public void clickTextBox() {
		TestBase.byXpath("textBoxButton").click();
	}
	
	 public void enterFullName()
	    {
	        TestBase.byXpath("fullName").sendKeys(TestData.getProperty("fullNameData"));
	    }

}
