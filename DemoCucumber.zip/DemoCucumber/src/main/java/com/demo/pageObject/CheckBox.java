package com.demo.pageObject;

import com.demo.base.TestBase;

public class CheckBox extends TestBase {
	public static TestBase base = new TestBase();
	
	public void init() throws Exception {
        TestBase.initilize();
    }
	public void clickCheckBox()
    {
        TestBase.byXpath("checkbox").click();
    }

}
