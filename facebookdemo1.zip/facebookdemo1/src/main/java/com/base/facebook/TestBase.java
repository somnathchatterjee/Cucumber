package com.base.facebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TestBase extends DriverManager {

   public static WebDriver driver;
   //ConfigarationManager configarationManager = new ConfigarationManager();


    public static void initilize() throws Exception{
       //DriverManager.configarationManager.conficfile();
        DriverManager.browser();
        driver=DriverManager.driver;
    }

    public static WebElement byXpath(String xpath){

        return driver.findElement(By.xpath(OR.getProperty(xpath)));
    }

    public static WebElement byId(String id){

        return driver.findElement(By.id(OR.getProperty(id)));
    }

    public  boolean isElementPresentXpath(String xpath1 )
    {
        WebElement data = driver.findElement(By.xpath(OR.getProperty(xpath1)));
        return true;
    }
}
