package com.utility;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {
    static{

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        System.setProperty("current", dateFormat.format(new Date()));
    }
    private static Logger Logs = Logger.getLogger(Log.class.getName());

    public Log() {

        PropertyConfigurator.configure(System.getProperty("user.dir")+"/src/main/resources/log4j.properties");
        // This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite
    }
    public static void startTestCase(String sTestCaseName){

        Logs.info(sTestCaseName);

    }

    //This is to print log for the ending of the test case

    public static void endTestCase(String sTestCaseName){

        Logs.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");

    }

    // Need to create these methods, so that they can be called

    public static void info(String message) {

        Logs.info(message);

    }

    public static void warn(String message) {

        Logs.warn(message);

    }

    public static void error(String message) {

        Logs.error(message);

    }

    public static void fatal(String message) {

        Logs.fatal(message);

    }

    public static void debug(String message) {

        Log.debug(message);

    }

}


