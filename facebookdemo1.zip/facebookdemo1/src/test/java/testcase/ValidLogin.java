package testcase;

import com.pageObject.Login;
import com.pageObject.Regester;
import org.testng.annotations.Test;


public class ValidLogin {

       public static Login log = new Login();
       public static Regester reg = new Regester();
       
    @Test
    public void verifyValidLogin() throws Exception {
        log.init();
        log.uname();
        log.pass();
        log.log();
    }
}
