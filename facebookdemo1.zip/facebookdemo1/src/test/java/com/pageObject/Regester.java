package com.pageObject;

import com.base.facebook.TestBase;

public class Regester extends TestBase {

    TestBase base = new TestBase();
    public void fname(){
        TestBase.byXpath("Fnane").sendKeys("Firstname");
    }

}
