package com.pageObject;

import com.base.facebook.TestBase;
import org.testng.annotations.Test;

public class Login extends TestBase {
    public static TestBase base = new TestBase();

    @Test
    public void init() throws Exception {
        base.initilize();
    }

    @Test
    public void uname()
    {
        base.byXpath("username").sendKeys(TestData.getProperty("uname"));
    }
    public void pass()
    {

        base.byXpath("password").sendKeys(TestData.getProperty("pass"));
    }
    public void log()
    {
        base.byXpath("login").click();
    }
}
